from codeforces import testing
def lambda_handler(event, context):
    # TODO implement
    testing()
    return 'Hello from Lambda'