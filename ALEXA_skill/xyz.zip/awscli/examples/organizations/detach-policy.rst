**To detach a policy from an OU**

The following example shows how to detach a policy from an OU.

Command::

  aws organizations detach-policy --target-id ou-examplerootid111-exampleouid111 --policy-id p-examplepolicyid111