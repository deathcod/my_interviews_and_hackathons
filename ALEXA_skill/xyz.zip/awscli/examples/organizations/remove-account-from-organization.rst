**To remove a member account from the organization as a user in the master account**

The following example shows how to remove member account 333333333333 from an organization.  

Command::

  aws organizations remove-account --account-id 333333333333