**To disable actions for an alarm**

The following example uses the ``disable-alarm-actions`` command to disable all actions for the alarm named myalarm.::

  aws cloudwatch disable-alarm-actions --alarm-names myalarm

This command returns to the prompt if successful.

